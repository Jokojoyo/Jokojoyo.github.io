import { build } from "vite";
import fs from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";
await build();
await build({build:{ssr:"src/render.tsx",outDir:".ssr",emptyOutDir:true}, publicDir:false});
const {render}=await import(pathToFileURL(path.resolve(".ssr/render.js")).href);
const dist=path.resolve("dist");
let html=await fs.readFile(path.join(dist,"index.html"),"utf8");
html=html.replace('<div id="root"></div>','<div id="root">'+render()+'</div>');
await fs.writeFile(path.join(dist,"index.html"),html);
const names=new Map();
const collect=async(dir)=>{for(const entry of await fs.readdir(dir,{withFileTypes:true})){const p=path.join(dir,entry.name);if(entry.isDirectory()) await collect(p);else names.set(path.relative(dist,p).replaceAll("\\","/"),entry.name)}};
await collect(dist);
for (const [rel,name] of names){
 const p=path.join(dist,rel);
 if(/\.(html|js|css|webmanifest)$/.test(name)){
  let s=await fs.readFile(p,"utf8");
  for(const [r,n] of names){s=s.replaceAll("/"+r,"/"+n)}
  s=s.replaceAll("/assets/projects/","/").replaceAll("/assets/icons/","/");
  await fs.writeFile(p,s);
 }
 if(rel.includes("/")) await fs.copyFile(p,path.join(dist,name));
}
await fs.rm(path.join(dist,"assets"),{recursive:true,force:true});
await fs.writeFile(path.join(dist,"robots.txt"),"User-agent: *\nAllow: /\nSitemap: https://jokojoyo.github.io/sitemap.xml\n");
await fs.writeFile(path.join(dist,"sitemap.xml"),'<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>https://jokojoyo.github.io/</loc></url></urlset>');
await fs.writeFile(path.join(dist,".nojekyll"),"");
console.log("Pre-rendered and flattened the GitHub Pages release.");
