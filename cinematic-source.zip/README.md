# Thomas Ginting: Websites with a sense of place

A cinematic portfolio of six original website concepts. The 15-second coastal film follows scroll position. Desktop and mobile encodes, reduced-motion fallback, motion switch, native keyboard navigation, self-hosted display and body fonts, and pre-rendered readable content are included.

## Develop

Requires Node.js 22.12 or newer. Run npm ci, then npm run dev. Run npm run build to create the GitHub Pages release in dist/. The output is flattened deliberately for browser-based GitHub uploads; upload every file in dist/ to the repository root. Assets are self-contained and there is no backend or paid hosting requirement.

## Assets

The coastal film, architecture image and navigation glyphs were generated with Higgsfield under the approved credit budget. Project screenshots and TG identity come from the original portfolio. Cormorant Garamond and Manrope use the SIL Open Font License. Every featured website is an original concept rather than a paid-client claim.
