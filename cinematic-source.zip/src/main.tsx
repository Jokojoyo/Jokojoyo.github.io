import { hydrateRoot, createRoot } from "react-dom/client";
import { PortfolioPage } from "./Portfolio";
import "./portfolio.css";
import "lenis/dist/lenis.css";
const el=document.getElementById("root")!;
if(el.hasChildNodes()) hydrateRoot(el,<PortfolioPage/>);else createRoot(el).render(<PortfolioPage/>);
