export function DirectionIcon({ name, className = "" }: { name: string; className?: string }) {
  return <img className={"direction-icon " + className} src={"/assets/icons/" + name + ".png"} alt="" role="presentation" aria-hidden="true" width="32" height="32" />;
}

export function JourneyContents() {
  return (
    <>
      <div className="opening-action">
        <a className="work-departure" href="#work">Selected work <DirectionIcon name="arrow" /></a>
      </div>
      <section className="journey-approach" aria-labelledby="approach-title">
        <div className="approach-copy">
          <h2 id="approach-title">Design you<br />can explore.</h2>
          <p>Thoughtful layouts, useful interactions, and motion that gives each website its own character.</p>
        </div>
      </section>
      <section className="journey-arrival" aria-labelledby="arrival-title">
        <div>
          <h2 id="arrival-title">Six ideas,<br />brought to life.</h2>
          <p>Explore original concepts for coffee, architecture, retail, productivity, commerce, and image editing.</p>
        </div>
      </section>
    </>
  );
}

export function StaticJourney() {
  return (
    <section className="static-journey" aria-label="Portfolio introduction">
      <div className="static-opening">
        <picture className="static-world" aria-hidden="true">
          <source media="(max-width: 860px)" srcSet="/assets/world/passage-mobile-poster.png" />
          <img src="/assets/world/passage-poster.png" alt="" role="presentation" width="1920" height="1080" fetchPriority="high" />
        </picture>
        <div className="static-opening-copy">
          <h1>Websites with<br />a sense of place.</h1>
          <p>I am Thomas Ginting. I design and build expressive websites that work.</p>
        </div>
      </div>
      <JourneyContents />
    </section>
  );
}

