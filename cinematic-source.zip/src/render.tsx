import { renderToString } from "react-dom/server";
import { PortfolioPage } from "./Portfolio";
export const render = () => renderToString(<PortfolioPage/>);
