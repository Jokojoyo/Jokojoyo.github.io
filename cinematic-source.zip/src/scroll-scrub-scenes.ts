import { createElement } from "react";
import type { ScrollScrubScene, ScrollScrubTheme } from "@/components/scroll-scrub/scroll-scrub";
import { JourneyContents } from "@/components/portfolio/journey-copy";

export const scrollScrubTheme: ScrollScrubTheme = {
  accent: "#24818A",
  background: "#F0F6F3",
  ink: "#153F46",
  muted: "#466268",
};

export const scrollScrubScenes: ScrollScrubScene[] = [{
  id: "passage",
  label: "Introduction",
  title: "Websites with a sense of place.",
  body: "I am Thomas Ginting. I design and build expressive websites that work.",
  clip: "/assets/world/passage.mp4",
  mobileClip: "/assets/world/passage-mobile.mp4",
  poster: "/assets/world/passage-poster.png",
  mobilePoster: "/assets/world/passage-mobile-poster.png",
  objectPosition: "50% 50%",
  mobileObjectPosition: "50% 50%",
  scroll: 3.8,
  linger: 0.12,
  actions: createElement(JourneyContents),
}];

