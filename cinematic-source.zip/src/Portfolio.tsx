import { useEffect, useRef, useState } from "react";
import Lenis from "lenis";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ScrollScrub } from "@/components/scroll-scrub/scroll-scrub";
import { scrollScrubScenes, scrollScrubTheme } from "@/scroll-scrub-scenes";
import { DirectionIcon, StaticJourney } from "@/components/portfolio/journey-copy";
import { StructuredData } from "@/components/StructuredData";


const projects = [
  { name: "Senja Coffee", slug: "senja-coffee", image: "senja", category: "Coffee & hospitality", description: "A coffee brand with an atmospheric product story, rich imagery, and a clear path from browsing to the menu." },
  { name: "Forma Studio", slug: "forma-studio", image: "forma", category: "Architecture & interiors", description: "An architecture portfolio built around generous project images, a restrained editorial grid, and purposeful detail." },
  { name: "Loom Store", slug: "loom-store", image: "loom", category: "Retail & product discovery", description: "A considered retail concept that makes product browsing feel tactile, with a distinct identity and clear shopping interactions." },
  { name: "Flowdesk", slug: "flowdesk", image: "flowdesk", category: "Productivity workspace", description: "An editable task workspace with sample projects. Add your own tasks and keep your work on your device." },
  { name: "MerchantBoard", slug: "merchantboard", image: "merchantboard", category: "Commerce & analytics", description: "A sales dashboard with editable sample orders, designed to make the everyday details of a store easy to understand." },
  { name: "ImageKit Studio", slug: "imagekit-studio", image: "imagekit", category: "Browser image tools", description: "A focused image workspace that brings useful visual editing tools into the browser through a clear, deliberate interface." },
];

const entityJson = JSON.stringify({
  "@context": "https://schema.org",
  "@graph": [
    { "@type": "Person", "@id": "https://jokojoyo.github.io/#person", name: "Thomas Ginting", url: "https://jokojoyo.github.io/", sameAs: ["https://github.com/Jokojoyo"] },
    { "@type": "WebSite", "@id": "https://jokojoyo.github.io/#website", name: "Thomas Ginting", url: "https://jokojoyo.github.io/", description: "Expressive websites, original concepts, and useful browser experiences by Thomas Ginting.", creator: { "@id": "https://jokojoyo.github.io/#person" } },
  ],
});

function Project({ project, index }: { project: (typeof projects)[number]; index: number }) {
  return (
    <article className={"project project-" + index}>
      <a className="project-window" href={"https://jokojoyo.github.io/" + project.slug + "/"} target="_blank" rel="noopener noreferrer" aria-label={"Open " + project.name + " website in a new tab"}>
        <img src={"/assets/projects/" + project.image + ".webp"} alt={project.name + " website preview"} width={index < 3 ? 1440 : index === 3 ? 1414 : 1424} height={index < 3 ? 746 : index === 3 ? 744 : 749} loading="lazy" decoding="async" />
        <span className="project-launch">Open website <DirectionIcon name="arrow" /></span>
      </a>
      <div className="project-caption">
        <div><p className="project-category">{project.category}</p><h3>{project.name}</h3></div>
        <span className="concept-label">Original concept</span>
      </div>
      <p className="project-description">{project.description}</p>
      <a className="source-thread" href={"https://github.com/Jokojoyo/" + project.slug} target="_blank" rel="noopener noreferrer">
        <DirectionIcon name="source" /> View source <span className="sr-only">for {project.name} (opens in a new tab)</span>
      </a>
    </article>
  );
}

export function PortfolioPage() {
  const [mounted, setMounted] = useState(false);
  const [motion, setMotion] = useState(false);
  const [systemReduced, setSystemReduced] = useState(false);
  const [menu, setMenu] = useState(false);
  const pageRef = useRef<HTMLDivElement>(null);
  const menuButton = useRef<HTMLButtonElement>(null);
  const navRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    const apply = () => {
      setSystemReduced(media.matches);
      let stored: string | null = null;
      try { stored = localStorage.getItem("thomas-portfolio-motion"); } catch { /* Motion still works when storage is unavailable. */ }
      setMotion(!media.matches && stored !== "off");
    };
    apply();
    setMounted(true);
    media.addEventListener("change", apply);
    return () => media.removeEventListener("change", apply);
  }, []);

  useEffect(() => {
    if (!menu) return;
    const nav = navRef.current;
    const first = nav?.querySelector<HTMLAnchorElement>("a");
    first?.focus();
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setMenu(false);
        menuButton.current?.focus();
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [menu]);

  useEffect(() => {
    if (!mounted || !motion || systemReduced || !pageRef.current) return;
    gsap.registerPlugin(ScrollTrigger);
    const lenis = new Lenis({ autoRaf: false, duration: 0.95, anchors: true });
    lenis.on("scroll", ScrollTrigger.update);
    const tick = (seconds: number) => lenis.raf(seconds * 1000);
    gsap.ticker.add(tick);
    const context = gsap.context(() => {
      gsap.from(".portfolio-header", { y: -12, duration: 0.85, ease: "power3.out" });
      gsap.utils.toArray<HTMLElement>(".project").forEach((item) => {
        gsap.fromTo(item, { y: 28 }, { y: -12, ease: "none", scrollTrigger: { trigger: item, start: "top bottom", end: "bottom top", scrub: 0.65 } });
      });
      gsap.fromTo(".about-architecture", { y: 34 }, { y: -18, ease: "none", scrollTrigger: { trigger: ".about", start: "top bottom", end: "bottom top", scrub: 0.75 } });
    }, pageRef);
    return () => {
      context.revert();
      gsap.ticker.remove(tick);
      lenis.destroy();
    };
  }, [mounted, motion, systemReduced]);

  const activeMotion = mounted && motion && !systemReduced;
  const toggleMotion = () => {
    const next = !motion;
    setMotion(next);
    try { localStorage.setItem("thomas-portfolio-motion", next ? "on" : "off"); } catch { /* Preference lasts for this visit. */ }
  };

  return (
    <div className="portfolio-page" id="top" ref={pageRef} data-motion={activeMotion ? "on" : "off"}>
      <StructuredData json={entityJson} />
      <a className="skip-link" href="#work">Skip to selected work</a>
      <header className="portfolio-header">
        <a className="name-signature" href="#top" aria-label="Thomas Ginting, back to top">Thomas Ginting<span>Independent web design</span></a>
        <nav className={"portfolio-nav" + (menu ? " is-open" : "")} id="portfolio-navigation" ref={navRef} aria-label="Main navigation">
          <a href="#work" onClick={() => setMenu(false)}>Work</a>
          <a href="#about" onClick={() => setMenu(false)}>About</a>
          <a href="https://github.com/Jokojoyo" target="_blank" rel="noopener noreferrer" onClick={() => setMenu(false)}>GitHub <span className="sr-only">(opens in a new tab)</span></a>
        </nav>
        <div className="header-controls">
          <button className="motion-switch" type="button" onClick={toggleMotion} aria-pressed={activeMotion} disabled={!mounted || systemReduced} aria-label={systemReduced ? "Motion off because reduced motion is enabled" : activeMotion ? "Pause motion" : "Enable motion"} title={systemReduced ? "Your device prefers reduced motion" : undefined}>
            <DirectionIcon name={activeMotion ? "pause" : "play"} /><span>Motion {activeMotion ? "on" : "off"}</span>
          </button>
          <button className="menu-switch" ref={menuButton} type="button" aria-controls="portfolio-navigation" aria-expanded={menu} aria-label={menu ? "Close navigation" : "Open navigation"} onClick={() => setMenu(!menu)}>
            <DirectionIcon name={menu ? "close" : "menu"} />
          </button>
        </div>
      </header>
      <main>
        <div className="journey" id="journey">
          {activeMotion ? <ScrollScrub className="passage" scenes={scrollScrubScenes} theme={scrollScrubTheme} /> : <StaticJourney />}
        </div>
        <section className="selected-work" id="work" aria-labelledby="work-title">
          <div className="work-heading"><span className="project-count" aria-hidden="true">6</span><div><h2 id="work-title">Selected work</h2><p>Original concepts. Real websites.<br />Open a project and try it yourself.</p></div></div>
          <div className="project-gallery">{projects.map((project, index) => <Project key={project.slug} project={project} index={index} />)}</div>
        </section>
        <section className="about" id="about" aria-labelledby="about-title">
          <div className="about-text">
            <h2 id="about-title">A thoughtful approach<br />to the web.</h2>
            <p>I am Thomas Ginting. I turn ideas into distinctive websites, from the first visual direction to the details of a working interface.</p>
            <p>These six original concepts explore different kinds of products. Each is a chance to bring design, movement, and useful interactions together.</p>
            <dl className="capabilities">
              <div><dt>Visual design</dt><dd>Identity, typography, composition, and a clear story.</dd></div>
              <div><dt>Frontend development</dt><dd>Responsive layouts, browser tools, and considered interactions.</dd></div>
              <div><dt>Careful finishing</dt><dd>Keyboard access, readable content, and performance that respects the visitor.</dd></div>
            </dl>
          </div>
          <figure className="about-architecture"><img src="/assets/architecture.webp" alt="Sculpted limestone passage overlooking a turquoise sea" width="2048" height="1152" loading="lazy" decoding="async" /><figcaption>Form, space, and a clear direction.</figcaption></figure>
        </section>
        <section className="closing" aria-labelledby="closing-title">
          <div><h2 id="closing-title">Explore the source.</h2><p>The code behind the work is on GitHub.</p></div>
          <a className="github-passage" href="https://github.com/Jokojoyo" target="_blank" rel="noopener noreferrer"><span>GitHub</span><DirectionIcon name="arrow" /><span className="sr-only">Thomas Ginting's profile (opens in a new tab)</span></a>
        </section>
      </main>
      <footer className="portfolio-footer"><span>Thomas Ginting</span><span>Six original concepts</span><a href="#top" className="return-route">Back to top <DirectionIcon name="arrow" /></a></footer>
      <a className="whatsapp-contact" href="https://wa.me/628991501070" target="_blank" rel="noopener noreferrer" aria-label="Chat with Thomas Ginting on WhatsApp (opens in a new tab)">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M21 11.5a9 9 0 0 1-13.2 8L3 21l1.5-4.8A9 9 0 1 1 21 11.5Z" /><path d="M8 10h8M8 14h5" /></svg>
        <span>WhatsApp me</span>
      </a>
    </div>
  );
}
