# Thomas Ginting: A Sense of Place
Design read: A personal portfolio for visitors judging Thomas's visual design and functional web work, with the cinematic atmosphere of the user's cruise-site reel.
Concept spine: A portfolio as a passage across a sculpted archipelago, arriving at six real working projects.
Delivery tier: cinema, with a dimensional film, scroll chapters, editorial project gallery, and motivated surrounding motion.
Animation mode: animated-website
Journey shape: single-shot. One 15-second continuous film gives a coherent world with no scene seams.
Journey:
- Opening, 0-5 seconds: a low establishing view across turquoise water toward a centered sculpted island. Headline: Websites with a sense of place. Body: I am Thomas Ginting. I design and build expressive websites that work.
- Approach, 5-10 seconds: a gentle elevated approach reveals architectural terraces and a pale curved passage. Headline: Design you can explore. Body: Thoughtful layouts, useful interactions, and motion that gives each website its own character.
- Arrival, 10-15 seconds: the camera settles above a luminous coastal pavilion. Headline: Six ideas, brought to life. Body: Explore original concepts for coffee, architecture, retail, productivity, commerce, and image editing.
World grammar: Photoreal sculptural coastal architecture, pale limestone islands, blue-green water, mist-grey sky, soft daylight from upper left, calm reflections, minimal detail near copy, consistent exposure, no lettering, one central subject, no hard cuts.
Mobile framing: All focal architecture inside the central 35 percent. Landscape edges expendable. Mobile has a separately optimized encode and exact first-frame poster; text is lower and controls have 44px targets.
Delivery budget: Desktop film <=32 MiB; mobile film <=16 MiB. Keep encoded films out of source bundle if total would exceed service's 32 MiB transfer limit, using durable storage through supported deployment bindings.
Journey meaning: The camera's gradual arrival echoes moving from a first impression into the maker's actual work.
Locked palette: Mist #F0F6F3; deep marine ink #153F46; one muted lagoon accent #24818A; secondary ink #466268. The palette derives from the reference's water and avoids the previous dark chrome stage.
Locked type: Cormorant Garamond display, Manrope interface and body. Serif is justified by the user's specific luxury editorial cruise-site reference, with modern sans keeping portfolio details clear.
Theme paradigm: Pristine Light, tinted with cool sea mist.
Background character: Full-bleed cinematic imagery in the journey, restrained atmospheric coastal textures in supporting sections.
Typography character: Editorial serif and sans.
Readability refinement: Use Cormorant at weight 600 for headings and project titles, with less compressed tracking (-0.025em) and generous leading. Opening title tops out at 96px. Manrope body is 16px on phones and 18px over the film on desktop, weight 500; navigation and actions use weight 600. Secondary ink is #36545B. A localized 96% mist veil travels with the opening words; later film chapters use 94% mist reading surfaces. This makes contrast independent of the moving landscape beneath the copy. Small project labels and links are enlarged. The prebuilt scroll engine and film remain unchanged.
Hero architecture: Massive image-first, restrained centered type, one focal island and one main action.
Section system: Gallery-led cadence, distinct from the preceding full-bleed journey.
Signature components: Diagonal staggered masonry; vertical rhythm lines; off-grid editorial; layered image crop frames.
Second-read moment: One oversized 6 as structure at the gallery entrance, reflecting the actual project count.
Section plan:
1. Opening: centered statement over film, name and one direct work CTA.
2. Approach: off-grid short editorial text over continuous film.
3. Arrival: bottom-led introduction to work, over continuous film.
4. Projects: staggered image-led gallery, six real project previews, title and concise purpose, live and source links.
5. About: one editorial column with architectural detail image and honest skills/capabilities.
6. Closing: oversized typographic GitHub link with a narrow ruled footer.
At least four layout families. Eyebrows: none beyond normal navigation and functional labels.
Mobile collapse: Gallery becomes one column; offset becomes spacing rather than sideways translation; nav becomes a compact menu; all text and actions remain usable.
Gallery display: Show the complete project screenshots at their native aspect ratios, using matching intrinsic dimensions and height:auto. Never crop screenshots into portrait frames or zoom them inside clipped frames on hover. Grid tracks use minmax(0,...) so content cannot force columns outside the page. On phones, project names and the original-concept label stack, allowing long names to wrap without clipping.
CTA inventory:
- Selected work: understated underlined hero link to the projects anchor.
- Open website: each project's image/title becomes a clear linked preview, with a small directional icon.
- View source: fine-rule text link under each project, visually secondary.
- GitHub: large outlined closing link with a restrained transform hover.
Each intent keeps one wording across the site; no shared generic button skin.
Asset plan: One six-keyframe storyboard, four section design boards (opening, gallery, about, closing), one custom navigation icon sheet, two candidate cover scenes, one selected launch cover composed with crisp type. Reuse the existing TG mark and six project screenshots as user's real assets. Encoded film posters supply the journey imagery.
Generation model plan: GPT Image 2, high quality, 2k for nine images. Cinema Studio Video 3.0, 15s, 1080p, silent, one continuous take using storyboard as generic image reference.
Credit preflight: Video 150 credits; image 6 credits (6.5 exact) each. Nine images plus video estimated 204 whole credits / 208.5 exact. Proposed cap 230 credits including limited image corrections, no second video without further agreement.
Credit authorization: user approved up to 230 existing Higgsfield credits. Community feed listing declined.
Accessibility: semantic heading order, visible keyboard focus, AA contrast, reduced-motion mode fetches no film, all work links accessible without motion, no autoplay audio, no video-dependent navigation.
Content truth: Six original concepts, no paid-client claims, invented results, testimonials, job titles, or public email.
Project links:
- Senja Coffee: https://jokojoyo.github.io/senja-coffee/ ; https://github.com/Jokojoyo/senja-coffee
- Forma Studio: https://jokojoyo.github.io/forma-studio/ ; https://github.com/Jokojoyo/forma-studio
- Loom Store: https://jokojoyo.github.io/loom-store/ ; https://github.com/Jokojoyo/loom-store
- Flowdesk: https://jokojoyo.github.io/flowdesk/ ; https://github.com/Jokojoyo/flowdesk
- MerchantBoard: https://jokojoyo.github.io/merchantboard/ ; https://github.com/Jokojoyo/merchantboard
- ImageKit Studio: https://jokojoyo.github.io/imagekit-studio/ ; https://github.com/Jokojoyo/imagekit-studio
Publication: The public portfolio is served at https://jokojoyo.github.io/ through GitHub Pages. The Higgsfield mirror has an authentication gateway, so GitHub Pages is the visitor-facing release. Community listing declined. Complete current source is supplied as cinematic-source.zip.
Reference limitation: Part of the Facebook reel was seen. Full playback was blocked by Facebook sign-in. Original footage is generated from the interpreted direction.


Anti-convergence ledger: Old ink/chrome palette becomes cool mist/marine; Space Grotesk becomes editorial Cormorant; left-copy knot hero becomes centered coastal film; rounded chrome controls become fine-rule links and sharp image frames; orbit/reset interactions become a scroll-driven camera passage. These changes deliberately distinguish the redesign on five axes.
Previous six identity axes: palette ink/chrome; type Space Grotesk/Manrope; hero left text/right knot; technique WebGL orbit; CTA rounded controls and small project actions; corners rounded panels. New axes: cool mist/marine; Cormorant/Manrope; centered film; scroll-scrub passage; fine-rule project links and a single large framed GitHub passage; sharp gallery frames. Six axes recorded, at least five clearly changed.
